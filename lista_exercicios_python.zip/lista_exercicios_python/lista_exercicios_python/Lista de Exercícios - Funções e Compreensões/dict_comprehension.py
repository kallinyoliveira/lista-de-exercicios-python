produtos_precos = {
    "Notebook"
}