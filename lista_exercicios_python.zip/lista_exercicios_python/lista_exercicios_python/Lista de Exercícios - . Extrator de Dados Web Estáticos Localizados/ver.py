import sqlite3

conexao = sqlite3.connect("dados.db")

cursor = conexao.cursor()

cursor.execute("SELECT * FROM links")

print(cursor.fetchall())

conexao.close()