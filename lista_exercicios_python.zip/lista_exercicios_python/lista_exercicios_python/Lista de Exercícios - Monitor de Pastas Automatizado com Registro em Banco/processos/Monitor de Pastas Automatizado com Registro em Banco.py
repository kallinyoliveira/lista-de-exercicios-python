import os
import shutil
import sqlite3
from datetime import datetime

# Banco
con = sqlite3.connect("arquivos.db")
cursor = con.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS arquivos (
    nome TEXT,
    titulo TEXT,
    data TEXT
)
""")

con.commit()
con.close()

while True:

    arquivos = os.listdir("../entrada")

    for arquivo in arquivos:

        if arquivo.endswith(".txt"):

            try:

                caminho = os.path.join("entrada", arquivo)

                with open(caminho, "r", encoding="utf-8") as arq:
                    titulo = arq.readline().strip()

                data = datetime.now().strftime("%d/%m/%Y")

                con = sqlite3.connect("arquivos.db")
                cursor = con.cursor()

                cursor.execute(
                    "INSERT INTO arquivos VALUES (?, ?, ?)",
                    (arquivo, titulo, data)
                )

                con.commit()
                con.close()

                shutil.move(
                    caminho,
                    os.path.join("processados", arquivo)
                )

                print(arquivo, "processado!")

            except:
                print("Erro ao processar:", arquivo)